import os
import tkinter as tk
from tkinter import ttk, messagebox

from utils import executar_backend, DELIMITADOR


class LoginWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.title("UNIPIM - Login")
        self.geometry("380x280") # Aumenta o tamanho para acomodar o título
        self.resizable(False, False)

        # Centraliza a janela
        self.update_idletasks()
        w = 380
        h = 280
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f'{w}x{h}+{x}+{y}')

        self.protocol("WM_DELETE_WINDOW", self.master.destroy)

        # Configuração de estilo para um visual mais moderno
        style = ttk.Style()
        style.theme_use('clam') # Tema mais moderno
        style.configure('TLabel', font=('Arial', 10))
        style.configure('TButton', font=('Arial', 10, 'bold'))
        style.configure('Title.TLabel', font=('Arial', 18, 'bold'), foreground='#00529B') # Cor institucional

        main_frame = ttk.Frame(self, padding="20")
        main_frame.pack(expand=True, fill="both")

        # Título UNIPIM proeminente
        ttk.Label(main_frame, text="UNIPIM", style='Title.TLabel').pack(pady=(0, 15))
        ttk.Label(main_frame, text="Sistema Acadêmico Colaborativo", font=('Arial', 10, 'italic')).pack(pady=(0, 15))

        # Frame para os campos de login
        login_frame = ttk.Frame(main_frame)
        login_frame.pack(pady=10)

        ttk.Label(login_frame, text="Login:").grid(row=0, column=0, sticky="w", pady=6)
        self.login_entry = ttk.Entry(login_frame, width=30)
        self.login_entry.grid(row=0, column=1, pady=6, padx=6)

        ttk.Label(login_frame, text="Senha:").grid(row=1, column=0, sticky="w", pady=6)
        self.senha_entry = ttk.Entry(login_frame, show="*", width=30)
        self.senha_entry.grid(row=1, column=1, pady=6, padx=6)

        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(pady=(10, 0))

        ttk.Button(btn_frame, text="Entrar", command=self.autenticar).grid(row=0, column=0, padx=10)
        ttk.Button(btn_frame, text="Sair", command=self.master.destroy).grid(row=0, column=1, padx=10)

        # dica sem revelar senhas
        hint = "Dica: para testes locais use adm/prof/aluno com senha 123 (fallback)."
        hint_label = ttk.Label(main_frame, text=hint, foreground="gray", font=('Arial', 8))
        hint_label.pack(pady=(15, 0))

        # tenta mostrar perfis do arquivo config/credentials.txt se existir
        creds_path = os.path.join(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")), "config",
                                  "credentials.txt")
        try:
            if os.path.isfile(creds_path):
                perfis = set()
                with open(creds_path, "r", encoding="utf-8") as f:
                    for line in f:
                        parts = line.strip().split("|")
                        if parts and parts[0]:
                            perfis.add(parts[0])
                if perfis:
                    hint_label.config(
                        text=hint_label.cget("text") + " Perfis: " + ", ".join(sorted(perfis)))
        except Exception:
            pass

    def autenticar(self):
        login = self.login_entry.get().strip()
        senha = self.senha_entry.get().strip()

        if not login or not senha:
            messagebox.showwarning("Aviso", "Preencha login e senha.")
            return

        dados = DELIMITADOR.join([login, senha])
        saida = executar_backend("autenticar", dados)

        if saida and saida.startswith("SUCESSO:"):
            perfil = saida.split(":", 1)[1]
            self.master.perfil_logado = perfil
            self.master.usuario_logado = login
            self.destroy()
            self.master.after_login()
            return

        # Se o backend não respondeu, assume que está indisponível
        if not saida:
            messagebox.showerror("Erro", "Backend indisponível. Verifique logs/backend.log")
            return

        # resposta do backend negou acesso
        messagebox.showerror("Erro de Login", "Login ou senha inválidos.")
