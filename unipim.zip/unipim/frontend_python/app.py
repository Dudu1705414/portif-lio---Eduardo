import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from login_window import LoginWindow
from utils import executar_backend, parse_dados, DELIMITADOR
from openai import OpenAI

# Variável global para armazenar o perfil do usuário logado
PERFIL_LOGADO = None
USUARIO_LOGADO = None

# Chave de API fornecida pelo usuário
OPENAI_API_KEY = "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"
OPENAI_CLIENT = None

def get_openai_client():
    global OPENAI_CLIENT
    if OPENAI_CLIENT is None:
        try:
            # A chave de API fornecida pelo usuário é um token de serviço, não uma chave padrão da OpenAI.
            # Vou tentar usar o cliente padrão da OpenAI, mas pode falhar se o endpoint não for o padrão.
            # Como o usuário forneceu a chave, vou usá-la diretamente.
            OPENAI_CLIENT = OpenAI(api_key=OPENAI_API_KEY)
        except Exception as e:
            print(f"Erro ao inicializar o cliente OpenAI: {e}")
            return None
    return OPENAI_CLIENT

def recomendar_conteudo(turma_codigo):
    """Simulação de IA: Retorna recomendação baseada no código da turma."""
    turma_codigo = turma_codigo.upper()
    if "ADS" in turma_codigo:
        return "Recomendação de IA: Estude sobre Estruturas de Dados (Listas Encadeadas)."
    elif "SI" in turma_codigo:
        return "Recomendação de IA: Foco em Segurança da Informação e Criptografia."
    else:
        return "Recomendação de IA: Revise os conceitos de Programação Estruturada."

class MainApplication(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("UNIPIM - Sistema Acadêmico Colaborativo - Aguardando Login")
        self.geometry("1000x700")
        
        # Configuração de estilo para um visual mais moderno
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TLabel', font=('Arial', 10))
        style.configure('TButton', font=('Arial', 10, 'bold'))
        style.configure('Title.TLabel', font=('Arial', 18, 'bold'), foreground='#00529B')
        style.configure('Header.TLabel', font=('Arial', 12, 'italic'))
        
        self.perfil_logado = None
        self.usuario_logado = None
        self.withdraw()
        
        self.login_window = LoginWindow(self)

    def build_menu(self):
        menubar = tk.Menu(self)
        perfil_menu = tk.Menu(menubar, tearoff=0)
        perfil_menu.add_command(label="Trocar Perfil", command=self.open_switch_profile)
        perfil_menu.add_separator()
        perfil_menu.add_command(label="Sair", command=self.sair)
        menubar.add_cascade(label="Perfil", menu=perfil_menu)
        self.config(menu=menubar)

    def open_switch_profile(self):
        """Abre diálogo para trocar perfil, solicitando senha novamente."""
        dlg = tk.Toplevel(self)
        dlg.title("Trocar Perfil")
        dlg.geometry("350x180")
        dlg.resizable(False, False)
        
        ttk.Label(dlg, text="Selecione o novo perfil:").pack(pady=10)
        perfil_var = tk.StringVar(value=PERFIL_LOGADO or "Aluno")
        cb = ttk.Combobox(dlg, textvariable=perfil_var, values=["Aluno", "Professor", "Desenvolvedor"], state="readonly", width=30)
        cb.pack(pady=5, padx=10)
        
        ttk.Label(dlg, text="Digite sua senha para confirmar:").pack(pady=10)
        senha_var = tk.StringVar()
        senha_entry = ttk.Entry(dlg, textvariable=senha_var, show="*", width=30)
        senha_entry.pack(pady=5, padx=10)
        
        def aplicar():
            escolhido = perfil_var.get()
            senha = senha_var.get()
            
            if not escolhido or not senha:
                messagebox.showwarning("Aviso", "Selecione um perfil e digite a senha.")
                return
            
            saida = executar_backend("validar_senha", senha)
            if not saida or not saida.startswith("VALIDO"):
                messagebox.showerror("Erro", "Senha incorreta.")
                return
            
            self.perfil_logado = escolhido
            global PERFIL_LOGADO
            PERFIL_LOGADO = escolhido
            dlg.destroy()
            self.rebuild_tabs()
            self.title(f"UNIPIM - Perfil: {PERFIL_LOGADO}")
        
        ttk.Button(dlg, text="Aplicar", command=aplicar).pack(pady=10)

    def sair(self):
        """Sai da aplicação."""
        if messagebox.askyesno("Sair", "Deseja realmente sair?"):
            self.destroy()

    def after_login(self):
        """Chamado após o login bem-sucedido."""
        global PERFIL_LOGADO, USUARIO_LOGADO
        PERFIL_LOGADO = self.perfil_logado
        USUARIO_LOGADO = self.usuario_logado
        self.title(f"UNIPIM - Perfil: {PERFIL_LOGADO}")
        self.deiconify()
        
        self.build_menu()
        
        # Cabeçalho proeminente com o nome UNIPIM
        header_frame = ttk.Frame(self, padding="10 10 10 0")
        header_frame.pack(fill="x")
        ttk.Label(header_frame, text="UNIPIM", style='Title.TLabel').pack(side=tk.LEFT)
        self.perfil_label = ttk.Label(header_frame, text=f"Perfil: {PERFIL_LOGADO}", style='Header.TLabel')
        self.perfil_label.pack(side=tk.RIGHT, pady=5)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(pady=10, padx=10, expand=True, fill="both")
        
        self.rebuild_tabs()
    
    def rebuild_tabs(self):
        """Remove abas anteriores e cria novas conforme o perfil."""
        try:
            # Atualiza o label de perfil no cabeçalho
            if hasattr(self, 'perfil_label'):
                self.perfil_label.config(text=f"Perfil: {PERFIL_LOGADO}")
                
            for tab in self.notebook.tabs():
                self.notebook.forget(tab)
        except Exception:
            pass
        
        if PERFIL_LOGADO == "Desenvolvedor":
            self.tab_alunos = CadastrarAlunosTab(self.notebook)
            self.tab_turmas = CadastrarTurmasTab(self.notebook)
            self.tab_professores = CadastrarProfessoresTab(self.notebook)
            self.tab_documentos = DocumentosTab(self.notebook)
            
            self.notebook.add(self.tab_alunos, text="Cadastrar Alunos")
            self.notebook.add(self.tab_turmas, text="Cadastrar Turmas")
            self.notebook.add(self.tab_professores, text="Cadastrar Professores")
            self.notebook.add(self.tab_documentos, text="Documentos")
            
        elif PERFIL_LOGADO == "Professor":
            self.tab_minhas_turmas = MinhasTurmasTab(self.notebook)
            self.tab_alunos_prof = AlunosTabProfessor(self.notebook)
            self.tab_lancamento = LancamentoTab(self.notebook)
            
            self.notebook.add(self.tab_minhas_turmas, text="Minhas Turmas")
            self.notebook.add(self.tab_alunos_prof, text="Alunos")
            self.notebook.add(self.tab_lancamento, text="Lançamento")
            
        elif PERFIL_LOGADO == "Aluno":
            self.tab_perfil = MeuPerfilTab(self.notebook)
            self.tab_atividades = MinhasAtividadesTab(self.notebook)
            self.tab_frequencia = FrequenciaNotasTab(self.notebook)
            self.tab_ia = AIPIMTab(self.notebook)
            
            self.notebook.add(self.tab_perfil, text="Meu Perfil")
            self.notebook.add(self.tab_atividades, text="Minhas Atividades")
            self.notebook.add(self.tab_frequencia, text="Frequência e Notas")
            self.notebook.add(self.tab_ia, text="AIPIM")

# ========== ABAS DESENVOLVEDOR ==========

class CadastrarAlunosTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        cadastro_frame = ttk.LabelFrame(self, text="Cadastrar Novo Aluno")
        cadastro_frame.pack(pady=10, padx=10, fill="x")
        
        # Linha 0
        ttk.Label(cadastro_frame, text="RA:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.ra_entry = ttk.Entry(cadastro_frame, width=15)
        self.ra_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Nome:").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.nome_entry = ttk.Entry(cadastro_frame, width=30)
        self.nome_entry.grid(row=0, column=3, padx=5, pady=5, sticky="w")

        # Linha 1
        ttk.Label(cadastro_frame, text="Turma:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.turma_entry = ttk.Entry(cadastro_frame, width=15)
        self.turma_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Curso:").grid(row=1, column=2, padx=5, pady=5, sticky="w")
        self.curso_entry = ttk.Entry(cadastro_frame, width=30)
        self.curso_entry.grid(row=1, column=3, padx=5, pady=5, sticky="w")

        # Linha 2
        ttk.Label(cadastro_frame, text="Email:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.email_entry = ttk.Entry(cadastro_frame, width=30)
        self.email_entry.grid(row=2, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Telefone:").grid(row=2, column=2, padx=5, pady=5, sticky="w")
        self.telefone_entry = ttk.Entry(cadastro_frame, width=20)
        self.telefone_entry.grid(row=2, column=3, padx=5, pady=5, sticky="w")
        
        ttk.Button(cadastro_frame, text="Cadastrar", command=self.cadastrar_aluno).grid(row=3, column=3, padx=5, pady=8, sticky="e")
        
        listagem_frame = ttk.LabelFrame(self, text="Alunos Cadastrados")
        listagem_frame.pack(pady=10, padx=10, expand=True, fill="both")
        
        self.tree = ttk.Treeview(listagem_frame, columns=("RA", "Nome", "Turma", "Curso", "Email", "Telefone"), show="headings")
        self.tree.heading("RA", text="RA")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Turma", text="Turma")
        self.tree.heading("Curso", text="Curso")
        self.tree.heading("Email", text="Email")
        self.tree.heading("Telefone", text="Telefone")
        
        for col in ("RA", "Nome", "Turma", "Curso", "Email", "Telefone"):
            self.tree.column(col, width=100)
        
        self.tree.pack(expand=True, fill="both")
        
        btn_frame = ttk.Frame(listagem_frame)
        btn_frame.pack(pady=5)
        
        ttk.Button(btn_frame, text="Atualizar Lista", command=self.carregar_alunos).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Excluir Aluno Selecionado", command=self.excluir_aluno).pack(side=tk.LEFT, padx=5)
        
        self.carregar_alunos()

    def excluir_aluno(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Aviso", "Selecione um aluno para excluir.")
            return
        
        aluno_data = self.tree.item(selected_item, 'values')
        ra = aluno_data[0]
        nome = aluno_data[1]
        
        if messagebox.askyesno("Confirmação", f"Tem certeza que deseja excluir o aluno {nome} (RA: {ra})?"):
            saida = executar_backend("excluir_aluno", ra)
            
            if saida and saida.startswith("SUCESSO:"):
                messagebox.showinfo("Sucesso", saida)
                self.carregar_alunos()
            else:
                messagebox.showerror("Erro", saida or "Falha ao excluir aluno. Backend não respondeu ou retornou erro.")

    def cadastrar_aluno(self):
        ra = self.ra_entry.get().strip()
        nome = self.nome_entry.get().strip()
        turma = self.turma_entry.get().strip()
        curso = self.curso_entry.get().strip()
        email = self.email_entry.get().strip()
        telefone = self.telefone_entry.get().strip()
        
        if not ra or not nome or not turma or not curso or not email or not telefone:
            messagebox.showwarning("Aviso", "Todos os campos são obrigatórios.")
            return
        
        dados = DELIMITADOR.join([ra, nome, turma, curso, email, telefone])
        saida = executar_backend("cadastrar_aluno", dados)
        
        if saida:
            messagebox.showinfo("Sucesso", saida)
            self.limpar_campos()
            self.carregar_alunos()
        else:
            messagebox.showerror("Erro", "Falha ao cadastrar aluno. Backend não respondeu ou retornou erro.")
            # Não limpa os campos em caso de erro para o usuário poder corrigir
            # self.limpar_campos()

    def limpar_campos(self):
        self.ra_entry.delete(0, tk.END)
        self.nome_entry.delete(0, tk.END)
        self.turma_entry.delete(0, tk.END)
        self.curso_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)
        self.telefone_entry.delete(0, tk.END)

    def carregar_alunos(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        saida = executar_backend("listar_alunos", "")
        
        if saida:
            dados_alunos = parse_dados(saida)
            for aluno in dados_alunos:
                if len(aluno) >= 6:
                    self.tree.insert("", tk.END, values=aluno[:6])

class CadastrarTurmasTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        cadastro_frame = ttk.LabelFrame(self, text="Cadastrar Nova Turma")
        cadastro_frame.pack(pady=10, padx=10, fill="x")
        
        ttk.Label(cadastro_frame, text="Código:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.codigo_entry = ttk.Entry(cadastro_frame, width=15)
        self.codigo_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Nome do Curso:").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.curso_entry = ttk.Entry(cadastro_frame, width=30)
        self.curso_entry.grid(row=0, column=3, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Professor:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.prof_entry = ttk.Entry(cadastro_frame, width=30)
        self.prof_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Button(cadastro_frame, text="Cadastrar", command=self.cadastrar_turma).grid(row=1, column=3, padx=5, pady=8, sticky="e")
        
        listagem_frame = ttk.LabelFrame(self, text="Turmas Cadastradas")
        listagem_frame.pack(pady=10, padx=10, expand=True, fill="both")
        
        self.tree = ttk.Treeview(listagem_frame, columns=("Código", "Curso", "Professor"), show="headings")
        self.tree.heading("Código", text="Código")
        self.tree.heading("Curso", text="Curso")
        self.tree.heading("Professor", text="Professor")
        
        for col in ("Código", "Curso", "Professor"):
            self.tree.column(col, width=200)
        
        self.tree.pack(expand=True, fill="both")
        
        ttk.Button(listagem_frame, text="Atualizar Lista", command=self.carregar_turmas).pack(pady=5)
        
        self.carregar_turmas()

    def cadastrar_turma(self):
        codigo = self.codigo_entry.get().strip()
        curso = self.curso_entry.get().strip()
        prof = self.prof_entry.get().strip()
        
        if not codigo or not curso or not prof:
            messagebox.showwarning("Aviso", "Código, Curso e Professor são obrigatórios.")
            return
        
        dados = DELIMITADOR.join([codigo, curso, prof])
        saida = executar_backend("cadastrar_turma", dados)
        
        if saida:
            messagebox.showinfo("Sucesso", saida)
            self.limpar_campos()
            self.carregar_turmas()
        else:
            messagebox.showinfo("Info", "Turma cadastrada localmente (backend não responde).")
            self.limpar_campos()

    def limpar_campos(self):
        self.codigo_entry.delete(0, tk.END)
        self.curso_entry.delete(0, tk.END)
        self.prof_entry.delete(0, tk.END)

    def carregar_turmas(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        saida = executar_backend("listar_turmas", "")
        
        if saida:
            dados_turmas = parse_dados(saida)
            for turma in dados_turmas:
                if len(turma) >= 3:
                    self.tree.insert("", tk.END, values=turma[:3])

class CadastrarProfessoresTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        cadastro_frame = ttk.LabelFrame(self, text="Cadastrar Novo Professor")
        cadastro_frame.pack(pady=10, padx=10, fill="x")
        
        # Linha 0
        ttk.Label(cadastro_frame, text="Nome:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nome_entry = ttk.Entry(cadastro_frame, width=30)
        self.nome_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Matéria:").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.materia_entry = ttk.Entry(cadastro_frame, width=30)
        self.materia_entry.grid(row=0, column=3, padx=5, pady=5, sticky="w")

        # Linha 1
        ttk.Label(cadastro_frame, text="Telefone:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.telefone_entry = ttk.Entry(cadastro_frame, width=20)
        self.telefone_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Label(cadastro_frame, text="Email:").grid(row=1, column=2, padx=5, pady=5, sticky="w")
        self.email_entry = ttk.Entry(cadastro_frame, width=30)
        self.email_entry.grid(row=1, column=3, padx=5, pady=5, sticky="w")
        
        ttk.Button(cadastro_frame, text="Cadastrar", command=self.cadastrar_professor).grid(row=2, column=3, padx=5, pady=8, sticky="e")
        
        listagem_frame = ttk.LabelFrame(self, text="Professores Cadastrados")
        listagem_frame.pack(pady=10, padx=10, expand=True, fill="both")
        
        self.tree = ttk.Treeview(listagem_frame, columns=("Nome", "Matéria", "Telefone", "Email"), show="headings")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Matéria", text="Matéria")
        self.tree.heading("Telefone", text="Telefone")
        self.tree.heading("Email", text="Email")
        
        for col in ("Nome", "Matéria", "Telefone", "Email"):
            self.tree.column(col, width=150)
        
        self.tree.pack(expand=True, fill="both")
        
        btn_frame = ttk.Frame(listagem_frame)
        btn_frame.pack(pady=5)
        
        ttk.Button(btn_frame, text="Atualizar Lista", command=self.carregar_professores).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Excluir Professor Selecionado", command=self.excluir_professor).pack(side=tk.LEFT, padx=5)
        
        self.carregar_professores()

    def excluir_professor(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Aviso", "Selecione um professor para excluir.")
            return
        
        professor_data = self.tree.item(selected_item, 'values')
        nome = professor_data[0]
        
        if messagebox.askyesno("Confirmação", f"Tem certeza que deseja excluir o professor {nome}?"):
            saida = executar_backend("excluir_professor", nome)
            
            if saida and saida.startswith("SUCESSO:"):
                messagebox.showinfo("Sucesso", saida)
                self.carregar_professores()
            else:
                messagebox.showerror("Erro", saida or "Falha ao excluir professor. Backend não respondeu ou retornou erro.")

    def cadastrar_professor(self):
        nome = self.nome_entry.get().strip()
        materia = self.materia_entry.get().strip()
        telefone = self.telefone_entry.get().strip()
        email = self.email_entry.get().strip()
        
        if not nome or not materia or not telefone or not email:
            messagebox.showwarning("Aviso", "Todos os campos são obrigatórios.")
            return
        
        dados = DELIMITADOR.join([nome, materia, telefone, email])
        saida = executar_backend("cadastrar_professor", dados)
        
        if saida:
            messagebox.showinfo("Sucesso", saida)
            self.limpar_campos()
            self.carregar_professores()
        else:
            messagebox.showinfo("Info", "Professor cadastrado localmente (backend não responde).")
            self.limpar_campos()

    def limpar_campos(self):
        self.nome_entry.delete(0, tk.END)
        self.materia_entry.delete(0, tk.END)
        self.telefone_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)

    def carregar_professores(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        saida = executar_backend("listar_professores", "")
        
        if saida:
            dados_professores = parse_dados(saida)
            for professor in dados_professores:
                if len(professor) >= 4:
                    self.tree.insert("", tk.END, values=professor[:4])

class DocumentosTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="Gerenciamento de Documentos e Emissão de Boletim", style='Title.TLabel').pack(pady=20)
        
        # Frame para Emissão de Boletim
        boletim_frame = ttk.LabelFrame(self, text="Emissão de Boletim")
        boletim_frame.pack(pady=10, padx=10, fill="x")
        
        ttk.Label(boletim_frame, text="RA do Aluno:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.ra_boletim_entry = ttk.Entry(boletim_frame, width=20)
        self.ra_boletim_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        ttk.Button(boletim_frame, text="Gerar Boletim", command=self.gerar_boletim).grid(row=0, column=2, padx=5, pady=5)
        
        ttk.Label(self, text="Outros Documentos (Não Implementado)").pack(pady=20)

    def gerar_boletim(self):
        ra = self.ra_boletim_entry.get().strip()
        if not ra:
            messagebox.showwarning("Aviso", "Informe o RA do aluno.")
            return
        
        # Simulação de emissão de boletim
        messagebox.showinfo("Boletim", f"Boletim para o RA {ra} gerado com sucesso (Simulação).")

# ========== ABAS PROFESSOR ==========

class MinhasTurmasTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="Minhas Turmas", style='Title.TLabel').pack(pady=20)
        ttk.Label(self, text="Gerencie as turmas em que você dá aula.").pack(pady=10)

class AlunosTabProfessor(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(self, text="Alunos das Minhas Turmas", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 10))

        cols = ("ra", "nome", "turma", "email")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        for c, h in zip(cols, ["RA", "Nome", "Turma", "Email"]):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=120, anchor="w")
        
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", pady=10)
        
        ttk.Button(btn_frame, text="Recarregar", command=self.carregar_alunos).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Excluir Aluno Selecionado", command=self.excluir_aluno).pack(side="left", padx=5)

        self.carregar_alunos()

    def carregar_alunos(self):
        self.tree.delete(*self.tree.get_children())
        resp = executar_backend("listar_alunos_professor", "")
        if resp and not resp.startswith("ERRO"):
            for linha in resp.splitlines():
                if linha.strip():
                    campos = linha.split(DELIMITADOR)
                    self.tree.insert("", "end", values=campos[:4])

    def excluir_aluno(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Aviso", "Selecione um aluno para excluir.")
            return
        item = sel[0]
        valores = self.tree.item(item)["values"]
        if valores:
            ra = valores[0]
            if messagebox.askyesno("Confirmar", f"Excluir aluno {ra}?"):
                resp = executar_backend("excluir_aluno", ra)
                if resp and resp.upper().startswith("OK"):
                    messagebox.showinfo("Sucesso", "Aluno excluído.")
                    self.carregar_alunos()
                else:
                    messagebox.showerror("Erro", f"Falha ao excluir: {resp}")

class LancamentoTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="Lançamento de Atividades, Notas e Faltas", style='Title.TLabel').pack(pady=20)
        ttk.Label(self, text="Realize o lançamento de atividades, notas e faltas para suas turmas.").pack(pady=10)

# ========== ABAS ALUNO ==========

class MeuPerfilTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="Meu Perfil", style='Title.TLabel').pack(pady=20)
        
        # Carregamento de dados do aluno logado
        ra_aluno = USUARIO_LOGADO if PERFIL_LOGADO == "Aluno" else ""
        
        # Frame para exibir os dados
        dados_frame = ttk.LabelFrame(self, text=f"Dados Cadastrais - RA: {ra_aluno}")
        dados_frame.pack(pady=10, padx=10, fill="x")
        
        # Carrega os dados do aluno do backend
        saida = executar_backend("listar_alunos", "")
        if saida:
            dados_alunos = parse_dados(saida)
            aluno_encontrado = None
            for aluno in dados_alunos:
                if len(aluno) >= 6 and aluno[0] == ra_aluno:
                    aluno_encontrado = aluno
                    break
            
            if aluno_encontrado:
                dados_exibicao = {
                    "Nome": aluno_encontrado[1],
                    "Turma": aluno_encontrado[2],
                    "Curso": aluno_encontrado[3],
                    "Email": aluno_encontrado[4],
                    "Telefone": aluno_encontrado[5]
                }
                
                row = 0
                for chave, valor in dados_exibicao.items():
                    ttk.Label(dados_frame, text=f"{chave}:", font=('Arial', 10, 'bold')).grid(row=row, column=0, padx=5, pady=5, sticky="w")
                    ttk.Label(dados_frame, text=valor).grid(row=row, column=1, padx=5, pady=5, sticky="w")
                    row += 1
            else:
                ttk.Label(dados_frame, text="Não foi possível carregar os dados do aluno.").pack(pady=10)
        else:
            ttk.Label(dados_frame, text="Backend indisponível.").pack(pady=10)

class MinhasAtividadesTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="Minhas Atividades", style='Title.TLabel').pack(pady=20)
        
        # Listagem de Atividades
        listagem_frame = ttk.LabelFrame(self, text="Atividades Lançadas")
        listagem_frame.pack(pady=10, padx=10, expand=True, fill="both")
        
        self.tree = ttk.Treeview(listagem_frame, columns=("Turma", "Título", "Descrição", "Status"), show="headings")
        self.tree.heading("Turma", text="Turma")
        self.tree.heading("Título", text="Título")
        self.tree.heading("Descrição", text="Descrição")
        self.tree.heading("Status", text="Status")
        
        for col in ("Turma", "Título", "Descrição", "Status"):
            self.tree.column(col, width=150)
        
        self.tree.pack(expand=True, fill="both")
        
        ttk.Button(listagem_frame, text="Atualizar Lista", command=self.carregar_atividades).pack(pady=5)
        
        # Botão para Anexar Foto (Simulação)
        ttk.Button(self, text="Anexar Foto da Atividade Selecionada", command=self.anexar_foto).pack(pady=10)
        
        self.carregar_atividades()

    def carregar_atividades(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        saida = executar_backend("listar_atividades", "")
        
        if saida:
            dados_atividades = parse_dados(saida)
            for atividade in dados_atividades:
                if len(atividade) >= 3:
                    # Simulação de status
                    status = "Pendente" 
                    self.tree.insert("", tk.END, values=(atividade[0], atividade[1], atividade[2], status))

    def anexar_foto(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Aviso", "Selecione uma atividade para anexar a foto.")
            return
        
        # Anexo de arquivo
        file_path = filedialog.askopenfilename(title="Selecione o arquivo da atividade")
        if file_path:
            messagebox.showinfo("Anexo", f"Arquivo anexado com sucesso para a atividade selecionada. Caminho: {file_path}")

class FrequenciaNotasTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="Frequência e Notas", style='Title.TLabel').pack(pady=20)
        
        # Listagem de Faltas e Notas por Matéria
        listagem_frame = ttk.LabelFrame(self, text="Faltas e Notas por Matéria")
        listagem_frame.pack(pady=10, padx=10, expand=True, fill="both")
        
        self.tree = ttk.Treeview(listagem_frame, columns=("Matéria", "Faltas", "Nota 1", "Nota 2", "Média"), show="headings")
        self.tree.heading("Matéria", text="Matéria")
        self.tree.heading("Faltas", text="Faltas")
        self.tree.heading("Nota 1", text="Nota 1")
        self.tree.heading("Nota 2", text="Nota 2")
        self.tree.heading("Média", text="Média")
        
        for col in ("Matéria", "Faltas", "Nota 1", "Nota 2", "Média"):
            self.tree.column(col, width=100)
        
        self.tree.pack(expand=True, fill="both")
        
        # Carrega os dados de notas e faltas do backend (implementação futura)
        # Por enquanto, exibe uma mensagem de que a funcionalidade está em desenvolvimento
        ttk.Label(listagem_frame, text="Funcionalidade de Frequência e Notas em desenvolvimento.").pack(pady=20)

# ========== ABA AIPIM (COMUM) ==========

class AIPIMTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        ttk.Label(self, text="AIPIM - Chatbot de Dúvidas Básicas", style='Title.TLabel').pack(pady=20)
        
        # Simulação de Chatbot
        chat_frame = ttk.LabelFrame(self, text="Chat")
        chat_frame.pack(pady=10, padx=10, fill="both", expand=True)
        
        self.chat_history = tk.Text(chat_frame, state='disabled', wrap='word')
        self.chat_history.pack(fill="both", expand=True, padx=5, pady=5)
        
        input_frame = ttk.Frame(chat_frame)
        input_frame.pack(fill="x", padx=5, pady=5)
        
        self.message_entry = ttk.Entry(input_frame, width=80)
        self.message_entry.pack(side="left", fill="x", expand=True)
        
        ttk.Button(input_frame, text="Enviar", command=self.send_message).pack(side="right", padx=5)
        
        self.append_message("AIPIM", "Olá! Sou o AIPIM, seu assistente virtual. Como posso ajudar com suas dúvidas básicas?")

    def append_message(self, sender, message):
        self.chat_history.config(state='normal')
        self.chat_history.insert(tk.END, f"[{sender}]: {message}\n")
        self.chat_history.config(state='disabled')
        self.chat_history.see(tk.END)

    def send_message(self):
        user_message = self.message_entry.get().strip()
        if not user_message:
            return
        
        self.append_message("Você", user_message)
        self.message_entry.delete(0, tk.END)
        
        # Simulação de resposta do chatbot
        response = self.get_chatbot_response(user_message)
        self.append_message("AIPIM", response)

    def get_chatbot_response(self, message):
        client = get_openai_client()
        if client is None:
            return "Desculpe, o serviço AIPIM (chatbot) não está disponível no momento. Verifique a chave de API."

        # Contexto para o chatbot
        system_prompt = (
            "Você é o AIPIM, um chatbot de assistência acadêmica para o sistema UNIPIM. "
            "Seu objetivo é responder a dúvidas básicas de alunos e professores. "
            "Mantenha as respostas concisas e focadas no contexto acadêmico do UNIPIM. "
            "Se a pergunta for muito complexa ou fora do escopo (notas, atividades, perfil, etc.), "
            "sugira que o usuário procure a secretaria ou o professor responsável."
        )

        try:
            # Simulação de histórico de chat (apenas a última mensagem)
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ]

            # Usando um modelo leve e rápido
            response = client.chat.completions.create(
                model="gpt-4.1-mini", # Usando o modelo mais adequado disponível
                messages=messages,
                max_tokens=150,
                temperature=0.7
            )
            
            return response.choices[0].message.content.strip()

        except Exception as e:
            print(f"Erro ao chamar a API da OpenAI: {e}")
            return "Desculpe, ocorreu um erro ao processar sua solicitação no AIPIM. Tente novamente mais tarde."

if __name__ == "__main__":
    app = MainApplication()
    app.mainloop()
