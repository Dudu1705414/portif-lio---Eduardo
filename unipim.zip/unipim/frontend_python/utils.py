import subprocess
import os

DELIMITADOR = ";"

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "backend.log")

def _log(msg: str):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except:
        pass

def executar_backend(operacao: str, dados: str = "") -> str:
    """Executa operação no backend C."""
    _log(f"===== EXEC =====\nop={operacao}\ndados={repr(dados)}")
    
    try:
        # Caminho correto do backend compilado
        exe_path = r"C:\unipim\bin\Debug\unipim.exe"
        data_share = r"C:\unipim\DATA_SHARE"
        
        if not os.path.isfile(exe_path):
            _log(f"[ERRO] Backend não encontrado em: {exe_path}")
            return ""
        
        cmd = [exe_path, data_share, operacao]
        if dados:
            cmd.append(dados)
        
        _log(f"cmd={cmd}")
        
        # executa com timeout
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=15,
            cwd=os.path.dirname(exe_path)
        )
        
        stdout = (proc.stdout or "").strip()
        stderr = (proc.stderr or "").strip()
        rc = proc.returncode
        
        _log(f"rc={rc}\nstdout={repr(stdout)}\nstderr={repr(stderr)}")
        
        if rc != 0:
            _log(f"[ERRO] Backend retornou código {rc}")
            return ""
        
        return stdout
        
    except subprocess.TimeoutExpired:
        _log("[ERRO] Backend timeout (15s)")
        return ""
    except FileNotFoundError:
        _log(f"[ERRO] Backend executável não encontrado: {exe_path}")
        return ""
    except Exception as e:
        _log(f"[EXCECAO] {type(e).__name__}: {str(e)}")
        return ""
    finally:
        _log("===== FIM =====\n")

def parse_dados(texto: str):
    """Parse de resposta do backend separada por DELIMITADOR."""
    if not texto:
        return []
    linhas = [l.strip() for l in texto.splitlines() if l.strip()]
    resultado = []
    for l in linhas:
        resultado.append(l.split(DELIMITADOR))
    return resultado
