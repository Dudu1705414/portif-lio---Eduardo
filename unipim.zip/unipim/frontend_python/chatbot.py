import urllib.request
import urllib.error
import json

CHATBOT_API_URL = "https://api.openai.com/v1/chat/completions"
CHATBOT_API_KEY = "sua-chave-openai-aqui"  # substitua pela sua chave OpenAI

def chat_aipim(mensagem: str, contexto: str = "aluno") -> str:
    """Chamada simples à API OpenAI usando bibliotecas padrão (não bloqueante quando chamado em thread)."""
    if not CHATBOT_API_KEY or CHATBOT_API_KEY == "sua-chave-openai-aqui":
        return "Erro: chave da API OpenAI não configurada em chatbot.py"

    prompts = {
        "aluno": f"Você é um assistente acadêmico para alunos do sistema PIM II. Responda em português. Pergunta: {mensagem}",
        "professor": f"Você é um assistente para professores do sistema PIM II. Responda em português. Pergunta: {mensagem}",
        "admin": f"Você é um assistente para administradores do sistema PIM II. Responda em português. Pergunta: {mensagem}",
    }

    payload = {
        "model": "gpt-3.5-turbo",
        "messages": [
            {"role": "system", "content": f"Assistente acadêmico AIPIM ({contexto})"},
            {"role": "user", "content": prompts.get(contexto, prompts["aluno"])}
        ],
        "max_tokens": 400,
        "temperature": 0.6,
    }

    headers = {
        "Authorization": f"Bearer {CHATBOT_API_KEY}",
        "Content-Type": "application/json",
    }

    req = urllib.request.Request(
        CHATBOT_API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        try:
            err = e.read().decode()
            return f"Erro OpenAI HTTP {e.code}: {err[:200]}"
        except Exception:
            return f"Erro OpenAI HTTP {e.code}"
    except urllib.error.URLError:
        return "Erro: falha de conexão com AIPIM"
    except Exception as e:
        return f"Erro AIPIM: {e}"