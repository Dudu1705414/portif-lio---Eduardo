#ifndef DADOS_H
#define DADOS_H

#define MAX_RA 15
#define MAX_NOME 100
#define MAX_CODIGO 15
#define MAX_PROFESSOR 100
#define MAX_LOGIN 30
#define MAX_SENHA 30
#define MAX_PERFIL 15
#define MAX_CURSO 50
#define MAX_EMAIL 100
#define MAX_TELEFONE 20
#define MAX_MATERIA 50

// Estrutura para representar um Aluno
typedef struct {
    char ra[MAX_RA];
    char nome[MAX_NOME];
    char codigo_turma[MAX_CODIGO];
    char curso[MAX_CURSO];
    char email[MAX_EMAIL];
    char telefone[MAX_TELEFONE];
} Aluno;

// Estrutura para representar uma Turma
typedef struct {
    char codigo[MAX_CODIGO];
    char nome_curso[MAX_CURSO]; // Nome do curso
    char professor[MAX_PROFESSOR];
} Turma;

// Estrutura para representar um Usuário
typedef struct {
    char login[MAX_LOGIN];
    char senha[MAX_SENHA];
    char perfil[MAX_PERFIL]; // Aluno, Professor, Desenvolvedor
} Usuario;

// Estrutura para representar um Professor
typedef struct {
    char nome[MAX_NOME];
    char materia[MAX_MATERIA];
    char telefone[MAX_TELEFONE];
    char email[MAX_EMAIL];
} Professor;

#endif // DADOS_H
