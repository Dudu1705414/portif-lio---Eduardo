#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dados.h"

#define DELIMITADOR ";"
#define MAX_PATH 256

// Variável global para armazenar o caminho base da pasta de dados (DATA_SHARE)
char DATA_PATH[MAX_PATH] = "";

// Função auxiliar para construir o caminho completo do arquivo
void construir_caminho(char *caminho_completo, const char *nome_arquivo) {
    strcpy(caminho_completo, DATA_PATH);
    strcat(caminho_completo, "/");
    strcat(caminho_completo, nome_arquivo);
}

// Função auxiliar para remover o caractere de nova linha (\n) de uma string
void remover_newline(char *str) {
    size_t len = strlen(str);
    if (len > 0 && str[len - 1] == '\n') {
        str[len - 1] = '\0';
    }
}

// --- Funções de Persistência (CRUD) ---

// Função para salvar um novo Aluno no arquivo
int salvar_aluno(Aluno a) {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "alunos.txt");
    FILE *fp = fopen(caminho, "a");
    if (fp == NULL) return 0;
    // RA;Nome;Turma;Curso;Email;Telefone
    fprintf(fp, "%s%s%s%s%s%s%s%s%s%s%s\n", 
            a.ra, DELIMITADOR, a.nome, DELIMITADOR, a.codigo_turma, DELIMITADOR, 
            a.curso, DELIMITADOR, a.email, DELIMITADOR, a.telefone);
    fclose(fp);
    return 1;
}

// Função para salvar uma nova Turma no arquivo
int salvar_turma(Turma t) {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "turmas.txt");
    FILE *fp = fopen(caminho, "a");
    if (fp == NULL) return 0;
    // Codigo;Nome_Curso;Professor
    fprintf(fp, "%s%s%s%s%s\n", t.codigo, DELIMITADOR, t.nome_curso, DELIMITADOR, t.professor);
    fclose(fp);
    return 1;
}

// Função para salvar um novo Professor no arquivo
int salvar_professor(Professor p) {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "professores.txt");
    FILE *fp = fopen(caminho, "a");
    if (fp == NULL) return 0;
    // Nome;Materia;Telefone;Email
    fprintf(fp, "%s%s%s%s%s%s%s\n", 
            p.nome, DELIMITADOR, p.materia, DELIMITADOR, 
            p.telefone, DELIMITADOR, p.email);
    fclose(fp);
    return 1;
}

// Função para salvar um novo Usuário no arquivo
int salvar_usuario(Usuario u) {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "usuarios.txt");
    FILE *fp = fopen(caminho, "a");
    if (fp == NULL) return 0;
    fprintf(fp, "%s%s%s%s%s\n", u.login, DELIMITADOR, u.senha, DELIMITADOR, u.perfil);
    fclose(fp);
    return 1;
}

// Função para salvar uma nova Atividade no arquivo
int salvar_atividade(char *dados) {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "atividades.txt");
    FILE *fp = fopen(caminho, "a");
    if (fp == NULL) return 0;
    fprintf(fp, "%s\n", dados); // Dados já formatados pelo Python
    fclose(fp);
    return 1;
}

// Função para listar todos os Alunos
void listar_alunos() {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "alunos.txt");
    FILE *fp = fopen(caminho, "r");
    if (fp == NULL) return; 

    char linha[256];
    while (fgets(linha, sizeof(linha), fp) != NULL) {
        remover_newline(linha);
        printf("%s\n", linha);
    }
    fclose(fp);
}

// Função para listar todas as Turmas
void listar_turmas() {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "turmas.txt");
    FILE *fp = fopen(caminho, "r");
    if (fp == NULL) return;

    char linha[256];
    while (fgets(linha, sizeof(linha), fp) != NULL) {
        remover_newline(linha);
        printf("%s\n", linha);
    }
    fclose(fp);
}

// Função para listar todos os Professores
void listar_professores() {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "professores.txt");
    FILE *fp = fopen(caminho, "r");
    if (fp == NULL) return;

    char linha[256];
    while (fgets(linha, sizeof(linha), fp) != NULL) {
        remover_newline(linha);
        printf("%s\n", linha);
    }
    fclose(fp);
}

// Função para listar todas as Atividades
void listar_atividades() {
    char caminho[MAX_PATH];
    construir_caminho(caminho, "atividades.txt");
    FILE *fp = fopen(caminho, "r");
    if (fp == NULL) return;

    char linha[256];
    while (fgets(linha, sizeof(linha), fp) != NULL) {
        remover_newline(linha);
        printf("%s\n", linha);
    }
    fclose(fp);
}

// Função de Autenticação
// Retorna o perfil se autenticado, ou NULL se falhar.
char* autenticar_usuario_avancado(const char *login, const char *senha) {
    // 1. Tenta autenticação padrão (Admin)
    char caminho[MAX_PATH];
    construir_caminho(caminho, "usuarios.txt");
    FILE *fp = fopen(caminho, "r");
    if (fp != NULL) {
        char linha[256];
        char temp_login[MAX_LOGIN], temp_senha[MAX_SENHA], temp_perfil[MAX_PERFIL];
        
        while (fgets(linha, sizeof(linha), fp) != NULL) {
            remover_newline(linha);
            
            char linha_copia[256];
            strcpy(linha_copia, linha);
            
            // Tokeniza a linha
            char *token = strtok(linha_copia, DELIMITADOR);
            if (token != NULL) strcpy(temp_login, token); else continue;
            
            token = strtok(NULL, DELIMITADOR);
            if (token != NULL) strcpy(temp_senha, token); else continue;
            
            token = strtok(NULL, DELIMITADOR);
            if (token != NULL) strcpy(temp_perfil, token); else continue;

            // Verifica se o login e senha correspondem
            if (strcmp(login, temp_login) == 0 && strcmp(senha, temp_senha) == 0) {
                fclose(fp);
                // Aloca memória para o perfil e retorna
                char *perfil_retorno = (char*)malloc(strlen(temp_perfil) + 1);
                if (perfil_retorno == NULL) return NULL; // Falha na alocação
                strcpy(perfil_retorno, temp_perfil);
                return perfil_retorno;
            }
        }
        fclose(fp);
    }

    // Tenta autenticação de Professor
    if (strcmp(senha, "123") == 0) {
        construir_caminho(caminho, "professores.txt");
        fp = fopen(caminho, "r");
        if (fp != NULL) {
            char linha[256];
            while (fgets(linha, sizeof(linha), fp) != NULL) {
                remover_newline(linha);
                char *token = strtok(linha, DELIMITADOR);
                // O primeiro token é o nome/código do professor
                if (token != NULL && strcmp(login, token) == 0) {
                    fclose(fp);
                    // Retorna "Professor"
                    char *perfil_retorno = (char*)malloc(strlen("Professor") + 1);
                    if (perfil_retorno == NULL) return NULL;
                    strcpy(perfil_retorno, "Professor");
                    return perfil_retorno;
                }
            }
            fclose(fp);
        }

        // 3. Tenta autenticação de Aluno (login=RA, senha="123")
        // Verifica se o login é um RA de aluno válido
        construir_caminho(caminho, "alunos.txt");
        fp = fopen(caminho, "r");
        if (fp != NULL) {
            char linha[256];
            while (fgets(linha, sizeof(linha), fp) != NULL) {
                remover_newline(linha);
                char *token = strtok(linha, DELIMITADOR);
                // O primeiro token é o RA do aluno
                if (token != NULL && strcmp(login, token) == 0) {
                    fclose(fp);
                    // Retorna "Aluno"
                    char *perfil_retorno = (char*)malloc(strlen("Aluno") + 1);
                    if (perfil_retorno == NULL) return NULL;
                    strcpy(perfil_retorno, "Aluno");
                    return perfil_retorno;
                }
            }
            fclose(fp);
        }
    }

    return NULL; // Falha na autenticação
}

void autenticar_usuario(char *login, char *senha) {
    char *perfil = autenticar_usuario_avancado(login, senha);
    
    if (perfil != NULL) {
        printf("SUCESSO:%s\n", perfil);
        free(perfil); // Libera a memória alocada
    } else {
        printf("ERRO: Login ou senha invalidos.\n");
    }
}

//Função principal 
int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("ERRO: Uso: %s <caminho_data_share> <operacao> [dados]\n", argv[0]);
        return 1;
    }

    // Define o caminho base dos dados
    strcpy(DATA_PATH, argv[1]);
    
    char *operacao = argv[2];

    // Autenticação
    if (strcmp(operacao, "autenticar") == 0) {
        if (argc < 4) {
            printf("ERRO: Dados insuficientes para autenticar.\n");
            return 1;
        }
        char *dados = argv[3]; 
        
        char *login = strtok(dados, DELIMITADOR);
        char *senha = strtok(NULL, DELIMITADOR);

        if (login != NULL && senha != NULL) {
            remover_newline(login);
            remover_newline(senha);
            autenticar_usuario(login, senha);
        } else {
            printf("ERRO: Formato de dados de autenticacao invalido.\n");
        }
        return 0;
    }

    // --- OPERAÇÕES DE CADASTRO (CREATE) ---
    else if (strcmp(operacao, "cadastrar_aluno") == 0) {
        if (argc < 4) {
            printf("ERRO: Dados insuficientes para cadastrar aluno.\n");
            return 1;
        }
        char *dados = argv[3]; // Espera-se: RA;Nome;Turma;Curso;Email;Telefone
        
        Aluno novo_aluno;
        char *token = strtok(dados, DELIMITADOR);
        if (token != NULL) strcpy(novo_aluno.ra, token); else { printf("ERRO: RA ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_aluno.nome, token); else { printf("ERRO: Nome ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_aluno.codigo_turma, token); else { printf("ERRO: Turma ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_aluno.curso, token); else { printf("ERRO: Curso ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_aluno.email, token); else { printf("ERRO: Email ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_aluno.telefone, token); else { printf("ERRO: Telefone ausente.\n"); return 1; }

        if (salvar_aluno(novo_aluno)) {
            printf("SUCESSO: Aluno %s cadastrado.\n", novo_aluno.nome);
        } else {
            printf("ERRO: Falha ao salvar aluno.\n");
        }
        return 0;
    } 
    
    else if (strcmp(operacao, "cadastrar_turma") == 0) {
        if (argc < 4) {
            printf("ERRO: Dados insuficientes para cadastrar turma.\n");
            return 1;
        }
        char *dados = argv[3]; // Espera-se: Codigo;Nome_Curso;Professor
        
        Turma nova_turma;
        char *token = strtok(dados, DELIMITADOR);
        if (token != NULL) strcpy(nova_turma.codigo, token); else { printf("ERRO: Codigo ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(nova_turma.nome_curso, token); else { printf("ERRO: Nome do Curso ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(nova_turma.professor, token); else { printf("ERRO: Professor ausente.\n"); return 1; }

        if (salvar_turma(nova_turma)) {
            printf("SUCESSO: Turma %s cadastrada.\n", nova_turma.nome_curso);
        } else {
            printf("ERRO: Falha ao salvar turma.\n");
        }
        return 0;
    }

    else if (strcmp(operacao, "cadastrar_professor") == 0) {
        if (argc < 4) {
            printf("ERRO: Dados insuficientes para cadastrar professor.\n");
            return 1;
        }
        char *dados = argv[3]; // Espera-se: Nome;Materia;Telefone;Email
        
        Professor novo_professor;
        char *token = strtok(dados, DELIMITADOR);
        if (token != NULL) strcpy(novo_professor.nome, token); else { printf("ERRO: Nome ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_professor.materia, token); else { printf("ERRO: Materia ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_professor.telefone, token); else { printf("ERRO: Telefone ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_professor.email, token); else { printf("ERRO: Email ausente.\n"); return 1; }

        if (salvar_professor(novo_professor)) {
            printf("SUCESSO: Professor %s cadastrado.\n", novo_professor.nome);
        } else {
            printf("ERRO: Falha ao salvar professor.\n");
        }
        return 0;
    }

    else if (strcmp(operacao, "cadastrar_usuario") == 0) {
        if (argc < 4) {
            printf("ERRO: Dados insuficientes para cadastrar usuario.\n");
            return 1;
        }
        char *dados = argv[3]; // Espera-se: Login;Senha;Perfil
        
        Usuario novo_usuario;
        char *token = strtok(dados, DELIMITADOR);
        if (token != NULL) strcpy(novo_usuario.login, token); else { printf("ERRO: Login ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_usuario.senha, token); else { printf("ERRO: Senha ausente.\n"); return 1; }
        
        token = strtok(NULL, DELIMITADOR);
        if (token != NULL) strcpy(novo_usuario.perfil, token); else { printf("ERRO: Perfil ausente.\n"); return 1; }

        if (salvar_usuario(novo_usuario)) {
            printf("SUCESSO: Usuario %s cadastrado.\n", novo_usuario.login);
        } else {
            printf("ERRO: Falha ao salvar usuario.\n");
        }
        return 0;
    }
    
    else if (strcmp(operacao, "cadastrar_atividade") == 0) {
        if (argc < 4) {
            printf("ERRO: Dados insuficientes para cadastrar atividade.\n");
            return 1;
        }
        char *dados = argv[3]; // Espera-se: Turma;Titulo;Descricao
        
        if (salvar_atividade(dados)) {
            printf("SUCESSO: Atividade cadastrada.\n");
        } else {
            printf("ERRO: Falha ao salvar atividade.\n");
        }
        return 0;
    }

    // --- OPERAÇÕES DE LISTAGEM (READ) ---
    else if (strcmp(operacao, "listar_alunos") == 0) {
        listar_alunos();
        return 0;
    } 
    
    else if (strcmp(operacao, "listar_turmas") == 0) {
        listar_turmas();
        return 0;
    }

    else if (strcmp(operacao, "listar_professores") == 0) {
        listar_professores();
        return 0;
    }
    
    else if (strcmp(operacao, "listar_atividades") == 0) {
        listar_atividades();
        return 0;
    }

    // --- OPERAÇÃO NÃO RECONHECIDA ---
    else {
        printf("ERRO: Operacao desconhecida: %s\n", operacao);
        return 1;
    }
}
